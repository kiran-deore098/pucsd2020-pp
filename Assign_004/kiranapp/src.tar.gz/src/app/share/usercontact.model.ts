export interface UserContact {
  id: number;
  firstname: string;
  lastname: string;
  email: string;
}
